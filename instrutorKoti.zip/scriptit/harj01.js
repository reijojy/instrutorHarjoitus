function kerro() {
    var luku1 = 0;
    var luku2 = 0;
    var tulos = 0;
    var elementti1 = document.getElementById("luku1");
    var elementti2 = document.getElementById("luku2");
    luku1 = Number(elementti1.value);
    luku2 = Number(elementti2.value);
    var kertoma = function (x, y) {
        return (x * y).toString();
    };
    console.log("luku1: " + luku1 + " luku2: " + luku2);
    document.getElementById("tulos").innerHTML = kertoma(luku1, luku2);
    //document.getElementById("tulos").innerHTML = "Pimpsis";   
}
function jsonita() {
    var firstName_e = document.getElementById("firstName");
    var lastName_e = document.getElementById("lastName");
    var email_e = document.getElementById("email");
    var hobby_e = document.getElementById("hobby");
    var channel_e = document.getElementById("channel");
    var firstName_a = firstName_e.getAttribute("name");
    var lastName_a = lastName_e.getAttribute("name");
    var email_a = email_e.getAttribute("name");
    var hobby_a = hobby_e.getAttribute("name");
    var channel_a = channel_e.getAttribute("name");
    var firstName = firstName_e.value;
    var lastName = lastName_e.value;
    var email = email_e.value;
    var hobby = hobby_e.value;
    var channel = channel_e.value;
    var detailObj = "{" + hobby_a + ":\"" + hobby + "\", " + channel_a + ":\"" + channel + "\"}";
    var instructorObj = "{" + firstName_a + ":\"" + firstName + "\", " + lastName_a + ":\"" + lastName +
        "\", " + email_a + ":\"" + email + "\"}";
    //JSON.parse
    console.log("Funktio jsonita detailObj string: " + detailObj);
    console.log("Funktio jsonita instrucotrObj string: " + instructorObj);
}
