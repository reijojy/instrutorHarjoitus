function kerro() {
    let luku1: number = 0;
    let luku2: number = 0;
    let tulos: number = 0;
    let elementti1 = <HTMLInputElement> document.getElementById("luku1");
    let elementti2 = <HTMLInputElement> document.getElementById("luku2");
       
    luku1  = Number(elementti1.value);
    luku2  = Number(elementti2.value);
        
    let kertoma = (x: number, y: number): string => {
        return (x * y).toString();
}
console.log("luku1: " + luku1 + " luku2: " + luku2);
document.getElementById("tulos").innerHTML = kertoma(luku1, luku2);
//document.getElementById("tulos").innerHTML = "Pimpsis";   
} 
function jsonita() {
    const firstName_e = <HTMLInputElement> document.getElementById("firstName");
    const lastName_e = <HTMLInputElement> document.getElementById("lastName");
    const email_e = <HTMLInputElement> document.getElementById("email");
    const hobby_e = <HTMLInputElement> document.getElementById("hobby");
    const channel_e = <HTMLInputElement> document.getElementById("channel");

    const firstName_a: string = firstName_e.getAttribute("name");
    const lastName_a: string = lastName_e.getAttribute("name");
    const email_a: string = email_e.getAttribute("name");
    const hobby_a: string = hobby_e.getAttribute("name");
    const channel_a: string = channel_e.getAttribute("name");
     
    const firstName: string = firstName_e.value; 
    const lastName: string = lastName_e.value; 
    const email: string = email_e.value;
    const hobby: string = hobby_e.value;
    const channel: string = channel_e.value;
    const detailObj: string = "{" + hobby_a + ":\"" +  hobby + "\", " + channel_a + ":\"" +  channel + "\"}";
    const instructorObj: string = "{" + firstName_a + ":\"" + firstName + "\", " + lastName_a + ":\"" + lastName + 
                    "\", " + email_a + ":\"" + email + "\"}";
    const embeddedInstructor: string = instructorObj.substr(0, instructorObj.length - 1) + ", " +
            "instructor_detail:"  + detailObj + "}";
    //JSON.parse
    console.log("Funktio jsonita detailObj string: " + detailObj);
    console.log("Funktio jsonita instrucotrObj string: " + instructorObj);
    console.log("Funktio jsonita embeddedInstructor string: " + embeddedInstructor);
}
